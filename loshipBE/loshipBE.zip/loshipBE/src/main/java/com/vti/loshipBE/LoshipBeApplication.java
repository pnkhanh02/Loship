package com.vti.loshipBE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoshipBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoshipBeApplication.class, args);
	}

}
